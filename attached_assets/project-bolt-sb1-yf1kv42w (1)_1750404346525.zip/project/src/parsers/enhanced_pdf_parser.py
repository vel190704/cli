import pdfplumber
import re
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
import json
from datetime import datetime

logger = logging.getLogger(__name__)

class EnhancedPDFParser:
    def __init__(self):
        self.financial_keywords = {
            'revenue': [
                'total revenue', 'revenues', 'net revenue', 'total revenues',
                'sales', 'total sales', 'net sales'
            ],
            'earnings': [
                'adjusted earnings', 'net earnings', 'net income', 'adjusted net income',
                'earnings attributable', 'adjusted earnings attributable'
            ],
            'cash_flow': [
                'operating cash flow', 'cash flow from operations', 'operating activities',
                'cash from operations', 'operational cash flow'
            ],
            'free_cash_flow': [
                'free cash flow', 'fcf', 'free cash'
            ],
            'capex': [
                'capital expenditure', 'capital expenditures', 'capex', 'capital investments',
                'capital spending', 'investments'
            ],
            'production': [
                'production', 'total production', 'oil production', 'gas production',
                'liquids production', 'oil equivalent', 'boe', 'mboe'
            ],
            'debt': [
                'total debt', 'net debt', 'debt', 'borrowings'
            ]
        }
        
        # Common units and their standardization
        self.unit_conversions = {
            'million': 1e6,
            'billion': 1e9,
            'thousand': 1e3,
            'mboe': 1e6,  # million barrels of oil equivalent
            'mmboe': 1e6,
            'boe': 1,
            'mboe/d': 1e6,  # million barrels per day
            'mbd': 1e6,     # million barrels per day
        }

    def parse_pdf(self, pdf_path: str) -> Dict[str, Any]:
        """Parse a PDF and extract financial information"""
        try:
            with pdfplumber.open(pdf_path) as pdf:
                # Extract text from all pages
                full_text = ""
                tables = []
                
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        full_text += page_text + "\n"
                    
                    # Extract tables
                    page_tables = page.extract_tables()
                    if page_tables:
                        tables.extend(page_tables)
                
                # Parse the extracted content
                parsed_data = self._parse_content(full_text, tables)
                parsed_data['source_file'] = pdf_path
                parsed_data['parsed_at'] = datetime.now().isoformat()
                
                return parsed_data
                
        except Exception as e:
            logger.error(f"Error parsing PDF {pdf_path}: {e}")
            return {
                'error': str(e),
                'source_file': pdf_path,
                'parsed_at': datetime.now().isoformat()
            }

    def _parse_content(self, text: str, tables: List[List[List[str]]]) -> Dict[str, Any]:
        """Parse extracted text and tables for financial information"""
        result = {
            'financial_metrics': {},
            'key_highlights': [],
            'quarter_info': {},
            'tables': [],
            'raw_text_sample': text[:1000] if text else ""
        }
        
        # Extract quarter and year information
        result['quarter_info'] = self._extract_quarter_info(text)
        
        # Extract financial metrics from text
        text_metrics = self._extract_metrics_from_text(text)
        result['financial_metrics'].update(text_metrics)
        
        # Extract financial metrics from tables
        table_metrics = self._extract_metrics_from_tables(tables)
        result['financial_metrics'].update(table_metrics)
        
        # Extract key highlights/bullet points
        result['key_highlights'] = self._extract_highlights(text)
        
        # Store processed tables
        result['tables'] = self._process_tables(tables)
        
        return result

    def _extract_quarter_info(self, text: str) -> Dict[str, Any]:
        """Extract quarter and year information"""
        quarter_info = {}
        
        # Look for quarter patterns
        quarter_patterns = [
            r'Q([1-4])\s+202([4-5])',
            r'([1-4])Q\s+202([4-5])',
            r'quarter\s+([1-4])\s+202([4-5])',
            r'first\s+quarter\s+202([4-5])',
            r'second\s+quarter\s+202([4-5])',
            r'third\s+quarter\s+202([4-5])',
            r'fourth\s+quarter\s+202([4-5])'
        ]
        
        for pattern in quarter_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                if 'first' in pattern:
                    quarter_info['quarter'] = 'Q1'
                elif 'second' in pattern:
                    quarter_info['quarter'] = 'Q2'
                elif 'third' in pattern:
                    quarter_info['quarter'] = 'Q3'
                elif 'fourth' in pattern:
                    quarter_info['quarter'] = 'Q4'
                else:
                    quarter_info['quarter'] = f"Q{match.group(1)}"
                
                # Extract year
                year_group = match.group(2) if len(match.groups()) > 1 else match.group(1)
                quarter_info['year'] = f"202{year_group}"
                break
        
        return quarter_info

    def _extract_metrics_from_text(self, text: str) -> Dict[str, Any]:
        """Extract financial metrics from text using pattern matching"""
        metrics = {}
        
        for metric_type, keywords in self.financial_keywords.items():
            for keyword in keywords:
                # Look for patterns like "Revenue: $50.2 billion" or "Revenue $50.2B"
                patterns = [
                    rf'{re.escape(keyword)}\s*:?\s*\$?([0-9,]+\.?[0-9]*)\s*(billion|million|thousand|B|M|K)',
                    rf'{re.escape(keyword)}\s*of\s*\$?([0-9,]+\.?[0-9]*)\s*(billion|million|thousand|B|M|K)',
                    rf'\$?([0-9,]+\.?[0-9]*)\s*(billion|million|thousand|B|M|K)\s*{re.escape(keyword)}',
                ]
                
                for pattern in patterns:
                    matches = re.finditer(pattern, text, re.IGNORECASE)
                    for match in matches:
                        try:
                            value_str = match.group(1).replace(',', '')
                            value = float(value_str)
                            unit = match.group(2).lower()
                            
                            # Convert to standard units (billions)
                            if unit in ['billion', 'b']:
                                standardized_value = value
                            elif unit in ['million', 'm']:
                                standardized_value = value / 1000
                            elif unit in ['thousand', 'k']:
                                standardized_value = value / 1000000
                            else:
                                standardized_value = value
                            
                            # Store the metric
                            if metric_type not in metrics:
                                metrics[metric_type] = []
                            
                            metrics[metric_type].append({
                                'value': standardized_value,
                                'original_value': value,
                                'unit': unit,
                                'context': match.group(0)
                            })
                            
                        except (ValueError, IndexError):
                            continue
        
        # Take the most likely value for each metric (usually the first or most common)
        final_metrics = {}
        for metric_type, values in metrics.items():
            if values:
                # Sort by value and take median to avoid outliers
                sorted_values = sorted(values, key=lambda x: x['value'])
                median_idx = len(sorted_values) // 2
                final_metrics[metric_type] = sorted_values[median_idx]['value']
        
        return final_metrics

    def _extract_metrics_from_tables(self, tables: List[List[List[str]]]) -> Dict[str, Any]:
        """Extract financial metrics from tables"""
        metrics = {}
        
        for table in tables:
            if not table or len(table) < 2:
                continue
            
            # Look for financial tables (usually have headers in first row)
            headers = [cell.lower().strip() if cell else "" for cell in table[0]]
            
            # Check if this looks like a financial table
            financial_indicators = ['revenue', 'earnings', 'cash', 'production', 'million', 'billion']
            if not any(indicator in ' '.join(headers) for indicator in financial_indicators):
                continue
            
            # Process each row
            for row_idx, row in enumerate(table[1:], 1):
                if not row:
                    continue
                
                # Look for metric names in first column
                first_cell = row[0].lower().strip() if row[0] else ""
                
                for metric_type, keywords in self.financial_keywords.items():
                    if any(keyword in first_cell for keyword in keywords):
                        # Look for numeric values in subsequent columns
                        for col_idx, cell in enumerate(row[1:], 1):
                            if cell:
                                value = self._extract_number_from_cell(cell)
                                if value is not None:
                                    metrics[f"{metric_type}_table"] = value
                                    break
        
        return metrics

    def _extract_number_from_cell(self, cell: str) -> Optional[float]:
        """Extract numeric value from table cell"""
        if not cell:
            return None
        
        # Remove common formatting
        cleaned = re.sub(r'[^\d.,\-()]', '', cell)
        
        # Handle parentheses (negative numbers)
        is_negative = '(' in cell and ')' in cell
        cleaned = cleaned.replace('(', '').replace(')', '')
        
        # Extract number
        number_match = re.search(r'([0-9,]+\.?[0-9]*)', cleaned)
        if number_match:
            try:
                value = float(number_match.group(1).replace(',', ''))
                return -value if is_negative else value
            except ValueError:
                return None
        
        return None

    def _extract_highlights(self, text: str) -> List[str]:
        """Extract key highlights and bullet points"""
        highlights = []
        
        # Look for bullet points and key statements
        bullet_patterns = [
            r'•\s*(.+?)(?=\n|•|$)',
            r'-\s*(.+?)(?=\n|-|$)',
            r'\*\s*(.+?)(?=\n|\*|$)',
            r'>\s*(.+?)(?=\n|>|$)'
        ]
        
        for pattern in bullet_patterns:
            matches = re.finditer(pattern, text, re.MULTILINE)
            for match in matches:
                highlight = match.group(1).strip()
                if len(highlight) > 20 and len(highlight) < 200:  # Reasonable length
                    highlights.append(highlight)
        
        # Look for key phrases
        key_phrases = [
            r'(strong performance.+?)(?=\.|;|\n)',
            r'(delivered.+?)(?=\.|;|\n)',
            r'(achieved.+?)(?=\.|;|\n)',
            r'(increased.+?)(?=\.|;|\n)',
            r'(decreased.+?)(?=\.|;|\n)'
        ]
        
        for pattern in key_phrases:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                phrase = match.group(1).strip()
                if len(phrase) > 30 and len(phrase) < 150:
                    highlights.append(phrase)
        
        # Remove duplicates and return top highlights
        unique_highlights = list(dict.fromkeys(highlights))
        return unique_highlights[:10]  # Top 10 highlights

    def _process_tables(self, tables: List[List[List[str]]]) -> List[Dict[str, Any]]:
        """Process and structure tables"""
        processed_tables = []
        
        for table_idx, table in enumerate(tables):
            if not table or len(table) < 2:
                continue
            
            processed_table = {
                'index': table_idx,
                'headers': table[0] if table else [],
                'rows': table[1:] if len(table) > 1 else [],
                'row_count': len(table) - 1,
                'col_count': len(table[0]) if table else 0
            }
            
            # Try to identify table type
            headers_text = ' '.join(processed_table['headers']).lower()
            if any(word in headers_text for word in ['revenue', 'earnings', 'cash']):
                processed_table['type'] = 'financial'
            elif any(word in headers_text for word in ['production', 'barrels', 'boe']):
                processed_table['type'] = 'production'
            else:
                processed_table['type'] = 'general'
            
            processed_tables.append(processed_table)
        
        return processed_tables

    def parse_multiple_pdfs(self, pdf_directory: str, company_name: str) -> Dict[str, Any]:
        """Parse multiple PDFs for a company"""
        pdf_dir = Path(pdf_directory)
        results = {
            'company': company_name,
            'reports': [],
            'summary': {},
            'parsed_at': datetime.now().isoformat()
        }
        
        # Find all PDF files
        pdf_files = list(pdf_dir.glob("*.pdf"))
        pdf_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)  # Newest first
        
        for pdf_file in pdf_files:
            logger.info(f"Parsing {pdf_file}")
            parsed_data = self.parse_pdf(str(pdf_file))
            
            if 'error' not in parsed_data:
                results['reports'].append(parsed_data)
        
        # Create summary of latest report
        if results['reports']:
            latest_report = results['reports'][0]
            results['summary'] = {
                'latest_quarter': latest_report.get('quarter_info', {}),
                'key_metrics': latest_report.get('financial_metrics', {}),
                'highlights': latest_report.get('key_highlights', [])[:5]
            }
        
        return results