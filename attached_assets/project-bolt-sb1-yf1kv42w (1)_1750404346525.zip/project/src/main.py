#!/usr/bin/env python3
"""
Oil & Gas Financial Chatbot - Main Entry Point

A conversational AI chatbot that analyzes quarterly financial reports
from major oil & gas companies (Shell, BP, ExxonMobil, Chevron).
"""

import asyncio
import argparse
import logging
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

from chat.enhanced_chatbot import EnhancedChatbot
from scrapers.enhanced_pdf_downloader import EnhancedPDFDownloader
from parsers.enhanced_pdf_parser import EnhancedPDFParser
from config.settings import setup_logging

def setup_argument_parser():
    """Setup command line argument parser"""
    parser = argparse.ArgumentParser(
        description="Oil & Gas Financial Analysis Chatbot",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python src/main.py                    # Start interactive chat
  python src/main.py --full-update     # Download, parse, and start chat
  python src/main.py --download-only   # Only download reports
  python src/main.py --parse-only      # Only parse existing reports
  python src/main.py --query "How did Shell perform?"  # Single query

Companies supported: Shell, BP, ExxonMobil, Chevron
        """
    )
    
    parser.add_argument(
        '--full-update',
        action='store_true',
        help='Download latest reports, parse them, and start chat'
    )
    
    parser.add_argument(
        '--download-only',
        action='store_true',
        help='Only download latest reports (no parsing or chat)'
    )
    
    parser.add_argument(
        '--parse-only',
        action='store_true',
        help='Only parse existing downloaded reports'
    )
    
    parser.add_argument(
        '--query',
        type=str,
        help='Process a single query and exit'
    )
    
    parser.add_argument(
        '--data-dir',
        type=str,
        default='data',
        help='Directory for storing data (default: data)'
    )
    
    parser.add_argument(
        '--log-level',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        default='INFO',
        help='Set logging level (default: INFO)'
    )
    
    parser.add_argument(
        '--no-ollama',
        action='store_true',
        help='Disable Ollama integration (use rule-based responses only)'
    )
    
    return parser

async def download_reports(data_dir: str):
    """Download latest reports"""
    print("📥 Downloading latest quarterly reports...")
    downloader = EnhancedPDFDownloader(data_dir)
    
    try:
        results = await downloader.download_all_latest_reports()
        
        total_downloads = sum(len(info.get('downloads', [])) for info in results.values())
        print(f"✅ Successfully downloaded {total_downloads} reports")
        
        # Show summary
        for company, info in results.items():
            downloads = info.get('downloads', [])
            if downloads:
                print(f"   • {info.get('company', company)}: {len(downloads)} reports")
            elif info.get('error'):
                print(f"   • {info.get('company', company)}: Error - {info['error']}")
        
        return results
        
    except Exception as e:
        print(f"❌ Error downloading reports: {e}")
        return {}

async def parse_reports(data_dir: str):
    """Parse downloaded reports"""
    print("📄 Parsing downloaded reports...")
    parser = EnhancedPDFParser()
    downloader = EnhancedPDFDownloader(data_dir)
    
    try:
        # Get list of downloaded reports
        downloaded_reports = downloader.get_downloaded_reports()
        
        total_parsed = 0
        for company_id, reports in downloaded_reports.items():
            if reports:
                company_dir = f"{data_dir}/raw/pdfs/{company_id}"
                parsed_results = parser.parse_multiple_pdfs(company_dir, company_id)
                
                report_count = len(parsed_results.get('reports', []))
                if report_count > 0:
                    print(f"   • {company_id}: {report_count} reports parsed")
                    total_parsed += report_count
                    
                    # Save parsed results
                    output_dir = Path(data_dir) / "processed" / "json"
                    output_dir.mkdir(parents=True, exist_ok=True)
                    
                    import json
                    output_file = output_dir / f"{company_id}_parsed.json"
                    with open(output_file, 'w') as f:
                        json.dump(parsed_results, f, indent=2)
        
        print(f"✅ Successfully parsed {total_parsed} reports")
        return True
        
    except Exception as e:
        print(f"❌ Error parsing reports: {e}")
        return False

async def process_single_query(query: str, data_dir: str, use_ollama: bool = True):
    """Process a single query"""
    print(f"🤔 Processing query: {query}")
    
    try:
        chatbot = EnhancedChatbot(data_dir)
        
        # Disable Ollama if requested
        if not use_ollama:
            chatbot.ollama.available = False
        
        response = await chatbot.process_single_query(query)
        
        if response['success']:
            print(f"\n🤖 Response: {response['response']['text']}")
            
            if response['response'].get('data'):
                print("\n📊 Additional Data:")
                data = response['response']['data']
                if isinstance(data, dict):
                    for key, value in data.items():
                        print(f"   • {key}: {value}")
        else:
            print(f"❌ Error: {response['error']}")
            
    except Exception as e:
        print(f"❌ Error processing query: {e}")

async def main():
    """Main entry point"""
    parser = setup_argument_parser()
    args = parser.parse_args()
    
    # Setup logging
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    print("🛢️  Oil & Gas Financial Analysis Chatbot")
    print("=" * 50)
    
    try:
        # Handle different modes
        if args.download_only:
            await download_reports(args.data_dir)
            
        elif args.parse_only:
            await parse_reports(args.data_dir)
            
        elif args.full_update:
            # Download and parse
            download_results = await download_reports(args.data_dir)
            if download_results:
                await parse_reports(args.data_dir)
            
            # Start chat
            print("\n🚀 Starting conversational interface...")
            chatbot = EnhancedChatbot(args.data_dir)
            if args.no_ollama:
                chatbot.ollama.available = False
            await chatbot.start_conversation()
            
        elif args.query:
            await process_single_query(args.query, args.data_dir, not args.no_ollama)
            
        else:
            # Default: start chat interface
            print("🚀 Starting conversational interface...")
            print("💡 Tip: Use --full-update to download latest reports first")
            
            chatbot = EnhancedChatbot(args.data_dir)
            if args.no_ollama:
                chatbot.ollama.available = False
            await chatbot.start_conversation()
            
    except KeyboardInterrupt:
        print("\n\n👋 Goodbye!")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        print(f"❌ Unexpected error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())