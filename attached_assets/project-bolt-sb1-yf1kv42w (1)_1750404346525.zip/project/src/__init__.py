"""
Oil & Gas Financial Chatbot Package
"""
__version__ = "1.0.0"