import logging
from typing import List, Dict, Any, Optional
from datetime import datetime
import json
from src.llm.ollama_interface import OllamaInterface
from src.analysis.financial_analyzer import FinancialAnalyzer
from src.utils.query_processor import QueryProcessor
from src.database.models import ChatSession, ChatMessage

logger = logging.getLogger(__name__)

class ConversationManager:
    def __init__(self, db_session, ollama_interface: OllamaInterface, financial_analyzer: FinancialAnalyzer):
        self.db_session = db_session
        self.ollama = ollama_interface
        self.analyzer = financial_analyzer
        self.query_processor = QueryProcessor()
        self.conversation_context = []
        self.user_preferences = {}
        
    def create_conversational_prompt(self, user_query: str, context: Dict[str, Any]) -> str:
        """Create a natural, conversational prompt for the LLM"""
        
        base_personality = """You are an expert financial analyst specializing in oil & gas companies with a conversational, helpful personality. You have access to the latest quarterly earnings reports from Shell, BP, ExxonMobil, and Chevron.

Your communication style should be:
- Conversational and natural, like ChatGPT or Claude
- Insightful and analytical, but accessible
- Enthusiastic about financial data and trends
- Able to explain complex concepts simply
- Proactive in offering additional insights
- Friendly and engaging

Always provide specific numbers, percentages, and comparisons when available. If you notice interesting trends or patterns, mention them proactively."""

        # Add recent conversation context
        conversation_history = ""
        if self.conversation_context:
            conversation_history = "\n\nRecent conversation context:\n"
            for msg in self.conversation_context[-3:]:  # Last 3 exchanges
                conversation_history += f"User: {msg.get('user', '')}\nAssistant: {msg.get('assistant', '')}\n"

        # Add financial data context
        financial_context = ""
        if context.get('financial_data'):
            financial_context = f"\n\nLatest Financial Data Available:\n{json.dumps(context['financial_data'], indent=2)}"
        
        if context.get('comparison_data'):
            financial_context += f"\n\nComparison Analysis:\n{json.dumps(context['comparison_data'], indent=2)}"

        # Add market insights
        market_context = ""
        if context.get('market_insights'):
            market_context = f"\n\nMarket Context:\n{context['market_insights']}"

        prompt = f"""{base_personality}

{conversation_history}

{financial_context}

{market_context}

User Question: {user_query}

Please provide a conversational, insightful response that directly addresses the user's question. Include specific financial metrics, trends, and your analytical insights. If relevant, suggest follow-up questions or related areas they might find interesting."""

        return prompt

    def generate_welcome_message(self) -> str:
        """Generate a personalized welcome message based on latest data"""
        try:
            # Get latest data summary
            latest_reports = self.analyzer.get_latest_reports_summary()
            
            if not latest_reports:
                return """Hey there! 👋 

I'm your Oil & Gas Financial Analyst, and I'm here to help you dive deep into the latest quarterly earnings from the major energy companies. 

I have access to the most recent financial reports from Shell, BP, ExxonMobil, and Chevron, and I can help you understand everything from revenue trends to production metrics, cash flow analysis, and strategic insights.

What would you like to explore? You could ask me something like:
• "How did the oil majors perform this quarter?"
• "Compare Shell and BP's latest results"
• "What's driving ExxonMobil's cash flow?"
• Or anything else that's on your mind about these companies!

What interests you most?"""

            # Create personalized welcome with latest data insights
            companies_with_data = list(latest_reports.keys())
            latest_quarter = max([data.get('latest_quarter', '') for data in latest_reports.values()])
            
            welcome = f"""Hey there! 👋 

Great timing! I've just analyzed the latest quarterly reports from {', '.join(companies_with_data[:-1])} and {companies_with_data[-1]} for {latest_quarter}.

Here's what's particularly interesting right now:
"""
            
            # Add key highlights
            for company, data in latest_reports.items():
                if data.get('key_highlight'):
                    welcome += f"• **{company}**: {data['key_highlight']}\n"
            
            welcome += f"""
I can help you dive deeper into any of these results, compare companies, analyze trends, or explore specific metrics like production efficiency, cash flow generation, or capital allocation strategies.

What catches your attention? Or is there something specific you'd like to understand about the energy sector right now?"""
            
            return welcome
            
        except Exception as e:
            logger.error(f"Error generating welcome message: {e}")
            return """Hey there! 👋 

I'm your Oil & Gas Financial Analyst, ready to help you explore the latest earnings and performance data from Shell, BP, ExxonMobil, and Chevron.

I can analyze quarterly results, compare companies, identify trends, and provide insights on everything from production metrics to cash flow strategies.

What would you like to dive into first?"""

    def process_query(self, user_query: str, session_id: Optional[str] = None) -> Dict[str, Any]:
        """Process user query and generate conversational response"""
        try:
            # Analyze the query
            query_analysis = self.query_processor.analyze_query(user_query)
            
            # Gather relevant financial data
            context = self._build_context(query_analysis)
            
            # Generate response using LLM if available
            if self.ollama.is_available():
                prompt = self.create_conversational_prompt(user_query, context)
                llm_response = self.ollama.generate_response(prompt)
                
                if llm_response:
                    response = self._enhance_response_with_data(llm_response, context)
                else:
                    response = self._generate_fallback_response(user_query, context)
            else:
                response = self._generate_fallback_response(user_query, context)
            
            # Update conversation context
            self._update_conversation_context(user_query, response['text'])
            
            # Save to database if session provided
            if session_id:
                self._save_to_session(session_id, user_query, response)
            
            return response
            
        except Exception as e:
            logger.error(f"Error processing query: {e}")
            return {
                'text': "I apologize, but I encountered an issue analyzing that request. Could you try rephrasing your question? I'm here to help with any oil & gas financial analysis you need!",
                'error': str(e)
            }

    def _build_context(self, query_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Build comprehensive context for the query"""
        context = {}
        
        try:
            companies = query_analysis.get('companies', [])
            quarters = query_analysis.get('quarters', [])
            metrics = query_analysis.get('metrics', [])
            query_type = query_analysis.get('type', 'general')
            
            if companies:
                if query_type == 'comparison' and len(companies) > 1:
                    context['comparison_data'] = self.analyzer.compare_companies(companies, quarters)
                elif query_type == 'trend' and companies:
                    context['trend_data'] = self.analyzer.analyze_trends(companies[0], metrics)
                else:
                    # Single company analysis
                    for company in companies:
                        company_data = self.analyzer.get_company_performance(company, quarters)
                        if company_data:
                            context['financial_data'] = context.get('financial_data', {})
                            context['financial_data'][company] = company_data
            
            # Add market context
            context['market_insights'] = self.analyzer.get_market_context()
            
            # Add recent performance summary
            if not context.get('financial_data') and not context.get('comparison_data'):
                context['recent_summary'] = self.analyzer.get_recent_performance_summary()
                
        except Exception as e:
            logger.error(f"Error building context: {e}")
            
        return context

    def _generate_fallback_response(self, user_query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Generate conversational fallback response when LLM is not available"""
        query_lower = user_query.lower()
        
        # Greeting responses
        if any(word in query_lower for word in ['hello', 'hi', 'hey', 'good morning', 'good afternoon']):
            return {
                'text': self.generate_welcome_message(),
                'type': 'welcome'
            }
        
        # Company-specific responses
        if 'shell' in query_lower:
            return self._generate_company_response('Shell', context)
        elif 'bp' in query_lower:
            return self._generate_company_response('BP', context)
        elif any(word in query_lower for word in ['exxon', 'exxonmobil']):
            return self._generate_company_response('ExxonMobil', context)
        elif 'chevron' in query_lower:
            return self._generate_company_response('Chevron', context)
        
        # Comparison responses
        if 'compare' in query_lower or 'vs' in query_lower:
            return self._generate_comparison_response(context)
        
        # Trend analysis
        if any(word in query_lower for word in ['trend', 'over time', 'growth', 'decline']):
            return self._generate_trend_response(context)
        
        # General market question
        return {
            'text': """That's a great question! I'd love to help you analyze the oil & gas sector. 

Based on the latest quarterly reports I have access to, I can provide insights on:

🏢 **Company Performance**: Detailed analysis of Shell, BP, ExxonMobil, and Chevron
📊 **Financial Metrics**: Revenue, earnings, cash flow, capex, and production data  
📈 **Trends & Comparisons**: Quarter-over-quarter growth, company comparisons, and market positioning
💡 **Strategic Insights**: Capital allocation, operational efficiency, and market outlook

Could you be more specific about what you'd like to explore? For example:
• "How did Shell perform this quarter?"
• "Compare the cash flow of all major oil companies"
• "What's the trend in oil production across these companies?"

What interests you most?""",
            'type': 'general'
        }

    def _generate_company_response(self, company: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Generate conversational response for company-specific queries"""
        company_data = context.get('financial_data', {}).get(company)
        
        if not company_data:
            return {
                'text': f"""I'd be happy to analyze {company} for you! Let me pull up their latest financial data...

Unfortunately, I don't have their most recent quarterly data readily available right now. This could be because:
• Their latest report hasn't been processed yet
• There might be an issue accessing their investor relations page
• The data is still being parsed from their PDF reports

Would you like me to try refreshing the data, or would you prefer to explore another company like Shell, BP, ExxonMobil, or Chevron? I can also help you understand what metrics are most important to track for oil & gas companies.""",
                'type': 'company_unavailable'
            }
        
        # Extract key metrics
        latest_quarter = company_data.get('latest_quarter', {})
        previous_quarter = company_data.get('previous_quarter', {})
        
        response_text = f"""Great choice! Let me break down {company}'s latest performance for you.

**{company} - Latest Quarter Highlights:**

"""
        
        # Add specific metrics with conversational tone
        if latest_quarter.get('revenue'):
            revenue = latest_quarter['revenue']
            response_text += f"💰 **Revenue**: ${revenue:.1f}B"
            
            if previous_quarter.get('revenue'):
                change = ((revenue - previous_quarter['revenue']) / previous_quarter['revenue']) * 100
                trend = "up" if change > 0 else "down"
                response_text += f" ({change:+.1f}% {trend} from last quarter)"
            response_text += "\n"
        
        if latest_quarter.get('adjusted_earnings'):
            earnings = latest_quarter['adjusted_earnings']
            response_text += f"📈 **Adjusted Earnings**: ${earnings:.1f}B"
            
            if previous_quarter.get('adjusted_earnings'):
                change = ((earnings - previous_quarter['adjusted_earnings']) / previous_quarter['adjusted_earnings']) * 100
                trend = "improvement" if change > 0 else "decline"
                response_text += f" ({change:+.1f}% {trend})"
            response_text += "\n"
        
        response_text += f"""
What stands out to me about {company}'s performance is their operational resilience in the current market environment. 

Would you like me to dive deeper into any specific area? I can analyze:
• Cash flow generation and capital efficiency
• Production trends and operational metrics  
• How they compare to their peers
• Strategic initiatives and future outlook

What aspect interests you most?"""
        
        return {
            'text': response_text,
            'type': 'company_analysis',
            'data': company_data
        }

    def _generate_comparison_response(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Generate conversational comparison response"""
        comparison_data = context.get('comparison_data')
        
        if not comparison_data:
            return {
                'text': """I'd love to help you compare companies! Comparisons are one of my favorite types of analysis because they reveal so much about competitive positioning and operational efficiency.

I can compare any combination of Shell, BP, ExxonMobil, and Chevron across metrics like:
• Revenue and earnings performance
• Cash flow generation and capital efficiency
• Production volumes and operational metrics
• Return on capital and profitability ratios

Which companies would you like me to compare, and what specific aspects are you most curious about? For example:
• "Compare Shell and BP's cash flow this quarter"
• "How do all four companies stack up on production efficiency?"
• "Which company has the best capital allocation strategy?"

What comparison would be most valuable for you?""",
                'type': 'comparison_prompt'
            }
        
        # Generate detailed comparison response
        response_text = "Excellent question! Here's how these companies stack up:\n\n"
        
        # Add comparison insights
        for metric, companies_data in comparison_data.items():
            response_text += f"**{metric.replace('_', ' ').title()}:**\n"
            
            # Sort companies by performance
            sorted_companies = sorted(companies_data.items(), key=lambda x: x[1], reverse=True)
            
            for i, (company, value) in enumerate(sorted_companies):
                rank = ["🥇", "🥈", "🥉", "4️⃣"][i] if i < 4 else f"{i+1}."
                response_text += f"{rank} {company}: ${value:.1f}B\n"
            
            response_text += "\n"
        
        response_text += "The competitive landscape is really interesting right now. Would you like me to explore what's driving these differences, or dive deeper into any specific company's strategy?"
        
        return {
            'text': response_text,
            'type': 'comparison_analysis',
            'data': comparison_data
        }

    def _generate_trend_response(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Generate trend analysis response"""
        return {
            'text': """I'd be happy to analyze trends for you! Trend analysis is crucial for understanding the trajectory of these energy companies.

I can help you identify trends in:
• Revenue and earnings growth patterns
• Cash flow generation consistency
• Production efficiency improvements
• Capital allocation strategies
• Market share evolution

Which company's trends would you like me to analyze? And what specific metrics are you most interested in tracking over time?

For example:
• "Show me Shell's revenue trend over the last 4 quarters"
• "How has ExxonMobil's cash flow changed this year?"
• "What's the production trend across all companies?"

What trend analysis would be most valuable for your understanding?""",
            'type': 'trend_prompt'
        }

    def _enhance_response_with_data(self, llm_response: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Enhance LLM response with structured data"""
        return {
            'text': llm_response,
            'type': 'llm_enhanced',
            'context': context,
            'timestamp': datetime.now().isoformat()
        }

    def _update_conversation_context(self, user_query: str, response: str):
        """Update conversation context for better continuity"""
        self.conversation_context.append({
            'user': user_query,
            'assistant': response[:200] + "..." if len(response) > 200 else response,
            'timestamp': datetime.now().isoformat()
        })
        
        # Keep only last 5 exchanges
        if len(self.conversation_context) > 5:
            self.conversation_context = self.conversation_context[-5:]

    def _save_to_session(self, session_id: str, user_query: str, response: Dict[str, Any]):
        """Save conversation to database session"""
        try:
            # Implementation for saving to database
            pass
        except Exception as e:
            logger.error(f"Error saving to session: {e}")