import requests
import logging
from typing import Dict, Any, Optional
import json

logger = logging.getLogger(__name__)

class OllamaInterface:
    def __init__(self, base_url: str = "http://localhost:11434", model: str = "llama3"):
        self.base_url = base_url
        self.model = model
        self.available = False
        self._check_availability()
    
    def _check_availability(self):
        """Check if Ollama is available"""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            if response.status_code == 200:
                models = response.json().get('models', [])
                model_names = [model['name'] for model in models]
                
                # Check if our preferred model is available
                if any(self.model in name for name in model_names):
                    self.available = True
                    logger.info(f"Ollama is available with model: {self.model}")
                else:
                    logger.warning(f"Ollama is running but model {self.model} not found. Available models: {model_names}")
                    # Try to use the first available model
                    if model_names:
                        self.model = model_names[0].split(':')[0]
                        self.available = True
                        logger.info(f"Using available model: {self.model}")
            else:
                logger.warning("Ollama is running but API not responding correctly")
        except requests.exceptions.RequestException as e:
            logger.info(f"Ollama not available: {e}")
            logger.info("Will use fallback responses. To enable LLM features, install and run Ollama:")
            logger.info("1. Download from https://ollama.ai")
            logger.info("2. Run: ollama serve")
            logger.info("3. Run: ollama pull llama3")
    
    def is_available(self) -> bool:
        """Check if Ollama is available"""
        return self.available
    
    def generate_response(self, prompt: str, max_tokens: int = 1000) -> Optional[str]:
        """Generate response using Ollama"""
        if not self.available:
            return None
        
        try:
            payload = {
                "model": self.model,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "num_predict": max_tokens,
                    "temperature": 0.7,
                    "top_p": 0.9
                }
            }
            
            response = requests.post(
                f"{self.base_url}/api/generate",
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                return result.get('response', '').strip()
            else:
                logger.error(f"Ollama API error: {response.status_code}")
                return None
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Error calling Ollama: {e}")
            return None
    
    def chat(self, messages: list, max_tokens: int = 1000) -> Optional[str]:
        """Chat interface for conversation"""
        if not self.available:
            return None
        
        try:
            # Convert messages to a single prompt
            prompt = ""
            for message in messages:
                role = message.get('role', 'user')
                content = message.get('content', '')
                if role == 'user':
                    prompt += f"User: {content}\n"
                elif role == 'assistant':
                    prompt += f"Assistant: {content}\n"
                elif role == 'system':
                    prompt = f"System: {content}\n" + prompt
            
            prompt += "Assistant: "
            
            return self.generate_response(prompt, max_tokens)
            
        except Exception as e:
            logger.error(f"Error in chat: {e}")
            return None