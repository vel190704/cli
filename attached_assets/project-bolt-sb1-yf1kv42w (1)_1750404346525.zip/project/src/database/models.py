from sqlalchemy import Column, Integer, String, Float, DateTime, Text, ForeignKey, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()

class Company(Base):
    __tablename__ = 'companies'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    symbol = Column(String(10), nullable=True)
    sector = Column(String(50), default='Oil & Gas')
    created_at = Column(DateTime, default=datetime.utcnow)
    
    reports = relationship("Report", back_populates="company")

class Report(Base):
    __tablename__ = 'reports'
    
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('companies.id'), nullable=False)
    quarter = Column(String(10), nullable=False)  # Q1, Q2, Q3, Q4
    year = Column(Integer, nullable=False)
    quarter_year = Column(String(20), nullable=False)  # Q1 2024
    file_path = Column(String(500), nullable=True)
    parsed_at = Column(DateTime, default=datetime.utcnow)
    
    company = relationship("Company", back_populates="reports")
    financial_data = relationship("FinancialData", back_populates="report")

class FinancialData(Base):
    __tablename__ = 'financial_data'
    
    id = Column(Integer, primary_key=True)
    report_id = Column(Integer, ForeignKey('reports.id'), nullable=False)
    metric_name = Column(String(100), nullable=False)
    value = Column(Float, nullable=False)
    unit = Column(String(20), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    report = relationship("Report", back_populates="financial_data")

class ChatSession(Base):
    __tablename__ = 'chat_sessions'
    
    id = Column(Integer, primary_key=True)
    session_id = Column(String(100), unique=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_activity = Column(DateTime, default=datetime.utcnow)
    
    messages = relationship("ChatMessage", back_populates="session")

class ChatMessage(Base):
    __tablename__ = 'chat_messages'
    
    id = Column(Integer, primary_key=True)
    session_id = Column(Integer, ForeignKey('chat_sessions.id'), nullable=False)
    user_message = Column(Text, nullable=False)
    bot_response = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    session = relationship("ChatSession", back_populates="messages")

def create_tables():
    """Create all tables"""
    from .database import DatabaseManager
    db_manager = DatabaseManager()
    Base.metadata.create_all(db_manager.engine)