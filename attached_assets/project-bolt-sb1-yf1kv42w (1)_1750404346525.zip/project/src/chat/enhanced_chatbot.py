import asyncio
import logging
from typing import Dict, Any, Optional
from datetime import datetime
from src.llm.conversation_manager import ConversationManager
from src.llm.ollama_interface import OllamaInterface
from src.analysis.financial_analyzer import FinancialAnalyzer
from src.scrapers.enhanced_pdf_downloader import EnhancedPDFDownloader
from src.parsers.enhanced_pdf_parser import EnhancedPDFParser
from src.database.models import create_tables
from src.database.database import DatabaseManager

logger = logging.getLogger(__name__)

class EnhancedChatbot:
    def __init__(self, data_dir: str = "data"):
        self.data_dir = data_dir
        self.db_manager = DatabaseManager()
        self.downloader = EnhancedPDFDownloader(data_dir)
        self.parser = EnhancedPDFParser()
        self.ollama = OllamaInterface()
        self.analyzer = FinancialAnalyzer(self.db_manager.get_session())
        self.conversation_manager = ConversationManager(
            self.db_manager.get_session(),
            self.ollama,
            self.analyzer
        )
        
        # Initialize database
        create_tables()
        
        self.session_id = None
        self.conversation_active = True

    async def start_conversation(self):
        """Start the conversational chatbot"""
        print("\n" + "="*60)
        print("🛢️  Oil & Gas Financial Analysis Chatbot")
        print("="*60)
        
        # Check for latest data
        await self._check_and_update_data()
        
        # Generate welcome message
        welcome_message = self.conversation_manager.generate_welcome_message()
        print(f"\n{welcome_message}\n")
        
        # Start conversation loop
        while self.conversation_active:
            try:
                user_input = input("\n💬 You: ").strip()
                
                if not user_input:
                    continue
                
                # Handle special commands
                if user_input.lower() in ['exit', 'quit', 'bye']:
                    print("\n👋 Thanks for using the Oil & Gas Financial Chatbot! Have a great day!")
                    break
                elif user_input.lower() in ['help', '?']:
                    self._show_help()
                    continue
                elif user_input.lower() == 'refresh':
                    print("\n🔄 Refreshing data...")
                    await self._update_all_data()
                    print("✅ Data refreshed successfully!")
                    continue
                elif user_input.lower() == 'clear':
                    self.conversation_manager.conversation_context = []
                    print("\n🧹 Conversation history cleared!")
                    continue
                
                # Process the query
                print("\n🤔 Analyzing your question...")
                response = self.conversation_manager.process_query(user_input, self.session_id)
                
                # Display response
                print(f"\n🤖 Assistant: {response['text']}")
                
                # Show additional data if available
                if response.get('data'):
                    self._display_additional_data(response['data'])
                
            except KeyboardInterrupt:
                print("\n\n👋 Goodbye!")
                break
            except Exception as e:
                logger.error(f"Error in conversation: {e}")
                print(f"\n❌ I apologize, but I encountered an error: {e}")
                print("Please try rephrasing your question or type 'help' for assistance.")

    async def _check_and_update_data(self):
        """Check if we have recent data, update if needed"""
        print("🔍 Checking for latest financial reports...")
        
        # Check if we have recent downloads
        downloaded_reports = self.downloader.get_downloaded_reports()
        
        if not any(downloaded_reports.values()):
            print("📥 No reports found. Downloading latest reports...")
            await self._update_all_data()
        else:
            print("✅ Found existing reports. Use 'refresh' command to update.")

    async def _update_all_data(self):
        """Download and parse all latest reports"""
        try:
            # Download latest reports
            print("📥 Downloading latest quarterly reports...")
            download_results = await self.downloader.download_all_latest_reports()
            
            # Parse downloaded reports
            print("📄 Parsing downloaded reports...")
            for company_id, download_info in download_results.items():
                if download_info.get('downloads'):
                    company_dir = f"{self.data_dir}/raw/pdfs/{company_id}"
                    parsed_results = self.parser.parse_multiple_pdfs(company_dir, company_id)
                    
                    # Store in database
                    await self._store_parsed_data(company_id, parsed_results)
            
            print("✅ Data update completed!")
            
        except Exception as e:
            logger.error(f"Error updating data: {e}")
            print(f"❌ Error updating data: {e}")

    async def _store_parsed_data(self, company_id: str, parsed_results: Dict[str, Any]):
        """Store parsed data in database"""
        try:
            # This would integrate with your database models
            # For now, we'll log the successful parsing
            logger.info(f"Parsed data for {company_id}: {len(parsed_results.get('reports', []))} reports")
        except Exception as e:
            logger.error(f"Error storing data for {company_id}: {e}")

    def _show_help(self):
        """Show help information"""
        help_text = """
🆘 **Help - Oil & Gas Financial Chatbot**

**Sample Questions:**
• "How did Shell perform this quarter?"
• "Compare BP and ExxonMobil's latest results"
• "What's Chevron's free cash flow trend?"
• "Which company has the highest production?"
• "Show me the latest earnings for all companies"

**Commands:**
• `refresh` - Download and parse latest reports
• `clear` - Clear conversation history
• `help` or `?` - Show this help
• `exit`, `quit`, or `bye` - Exit the chatbot

**Companies Covered:**
• Shell (SHEL)
• BP (BP)
• ExxonMobil (XOM)
• Chevron (CVX)

**Metrics Available:**
• Revenue & Earnings
• Cash Flow & Free Cash Flow
• Capital Expenditure (CapEx)
• Production Volumes
• Debt & Financial Ratios

Just ask me anything about these companies' financial performance!
        """
        print(help_text)

    def _display_additional_data(self, data: Dict[str, Any]):
        """Display additional structured data"""
        if isinstance(data, dict):
            print("\n📊 **Additional Details:**")
            for key, value in data.items():
                if isinstance(value, (int, float)):
                    print(f"   • {key.replace('_', ' ').title()}: {value:.2f}")
                elif isinstance(value, str) and len(value) < 100:
                    print(f"   • {key.replace('_', ' ').title()}: {value}")

    async def process_single_query(self, query: str) -> Dict[str, Any]:
        """Process a single query (for API use)"""
        try:
            response = self.conversation_manager.process_query(query)
            return {
                'success': True,
                'response': response,
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"Error processing query: {e}")
            return {
                'success': False,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }

# CLI entry point
async def main():
    """Main CLI entry point"""
    chatbot = EnhancedChatbot()
    await chatbot.start_conversation()

if __name__ == "__main__":
    asyncio.run(main())