import re
import logging
from typing import Dict, List, Any

logger = logging.getLogger(__name__)

class QueryProcessor:
    def __init__(self):
        self.company_patterns = {
            'shell': ['shell', 'royal dutch shell', 'rds'],
            'bp': ['bp', 'british petroleum'],
            'exxonmobil': ['exxon', 'exxonmobil', 'exxon mobil', 'xom'],
            'chevron': ['chevron', 'cvx']
        }
        
        self.metric_patterns = {
            'revenue': ['revenue', 'sales', 'income', 'turnover'],
            'earnings': ['earnings', 'profit', 'net income', 'adjusted earnings'],
            'cash_flow': ['cash flow', 'operating cash', 'free cash flow', 'fcf'],
            'production': ['production', 'output', 'barrels', 'boe', 'oil production'],
            'capex': ['capex', 'capital expenditure', 'investments', 'capital spending']
        }
        
        self.quarter_patterns = {
            'q1': ['q1', 'first quarter', '1st quarter'],
            'q2': ['q2', 'second quarter', '2nd quarter'],
            'q3': ['q3', 'third quarter', '3rd quarter'],
            'q4': ['q4', 'fourth quarter', '4th quarter']
        }
    
    def analyze_query(self, query: str) -> Dict[str, Any]:
        """Analyze user query to extract intent and entities"""
        query_lower = query.lower()
        
        analysis = {
            'companies': [],
            'metrics': [],
            'quarters': [],
            'years': [],
            'type': 'general',
            'intent': 'information'
        }
        
        # Extract companies
        for company, patterns in self.company_patterns.items():
            if any(pattern in query_lower for pattern in patterns):
                analysis['companies'].append(company)
        
        # Extract metrics
        for metric, patterns in self.metric_patterns.items():
            if any(pattern in query_lower for pattern in patterns):
                analysis['metrics'].append(metric)
        
        # Extract quarters
        for quarter, patterns in self.quarter_patterns.items():
            if any(pattern in query_lower for pattern in patterns):
                analysis['quarters'].append(quarter)
        
        # Extract years
        year_matches = re.findall(r'202[4-5]', query)
        analysis['years'] = list(set(year_matches))
        
        # Determine query type
        if 'compare' in query_lower or 'vs' in query_lower or len(analysis['companies']) > 1:
            analysis['type'] = 'comparison'
        elif any(word in query_lower for word in ['trend', 'over time', 'growth', 'change']):
            analysis['type'] = 'trend'
        elif analysis['companies'] and analysis['metrics']:
            analysis['type'] = 'specific_metric'
        elif analysis['companies']:
            analysis['type'] = 'company_overview'
        
        # Determine intent
        if any(word in query_lower for word in ['how', 'what', 'show', 'tell']):
            analysis['intent'] = 'information'
        elif any(word in query_lower for word in ['compare', 'difference', 'better', 'worse']):
            analysis['intent'] = 'comparison'
        elif any(word in query_lower for word in ['why', 'reason', 'cause']):
            analysis['intent'] = 'explanation'
        
        return analysis