import asyncio
import aiohttp
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import re
from bs4 import BeautifulSoup
import json

logger = logging.getLogger(__name__)

class EnhancedPDFDownloader:
    def __init__(self, data_dir: str = "data"):
        self.data_dir = Path(data_dir)
        self.raw_dir = self.data_dir / "raw" / "pdfs"
        self.raw_dir.mkdir(parents=True, exist_ok=True)
        
        # Enhanced company configurations with multiple URL patterns
        self.companies = {
            'shell': {
                'name': 'Shell',
                'base_urls': [
                    'https://www.shell.com/investors/financial-reporting/quarterly-results.html',
                    'https://www.shell.com/investors/financial-reporting.html'
                ],
                'search_patterns': [
                    r'quarterly.*results.*202[4-5]',
                    r'q[1-4].*202[4-5].*results',
                    r'earnings.*202[4-5]',
                    r'financial.*results.*202[4-5]'
                ],
                'pdf_indicators': ['pdf', 'quarterly', 'results', 'earnings']
            },
            'bp': {
                'name': 'BP',
                'base_urls': [
                    'https://www.bp.com/en/global/corporate/investors/results-and-reporting/quarterly-results.html',
                    'https://www.bp.com/en/global/corporate/investors.html'
                ],
                'search_patterns': [
                    r'quarterly.*report.*202[4-5]',
                    r'q[1-4].*202[4-5]',
                    r'results.*202[4-5]'
                ],
                'pdf_indicators': ['pdf', 'quarterly', 'report', 'results']
            },
            'exxonmobil': {
                'name': 'ExxonMobil',
                'base_urls': [
                    'https://corporate.exxonmobil.com/investors/quarterly-earnings',
                    'https://corporate.exxonmobil.com/investors'
                ],
                'search_patterns': [
                    r'quarterly.*earnings.*202[4-5]',
                    r'q[1-4].*202[4-5].*earnings',
                    r'earnings.*release.*202[4-5]'
                ],
                'pdf_indicators': ['pdf', 'earnings', 'quarterly', 'release']
            },
            'chevron': {
                'name': 'Chevron',
                'base_urls': [
                    'https://www.chevron.com/investors/quarterly-earnings',
                    'https://www.chevron.com/investors'
                ],
                'search_patterns': [
                    r'quarterly.*earnings.*202[4-5]',
                    r'q[1-4].*202[4-5]',
                    r'earnings.*202[4-5]'
                ],
                'pdf_indicators': ['pdf', 'earnings', 'quarterly']
            }
        }

    async def download_all_latest_reports(self) -> Dict[str, Any]:
        """Download latest reports for all companies"""
        results = {}
        
        async with aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=30),
            headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
        ) as session:
            
            tasks = []
            for company_id in self.companies.keys():
                task = self.download_company_reports(session, company_id)
                tasks.append(task)
            
            company_results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for company_id, result in zip(self.companies.keys(), company_results):
                if isinstance(result, Exception):
                    logger.error(f"Error downloading {company_id}: {result}")
                    results[company_id] = {'error': str(result), 'downloads': []}
                else:
                    results[company_id] = result
        
        # Save summary
        summary_file = self.data_dir / "download_summary.json"
        with open(summary_file, 'w') as f:
            json.dump({
                'timestamp': datetime.now().isoformat(),
                'results': results
            }, f, indent=2)
        
        return results

    async def download_company_reports(self, session: aiohttp.ClientSession, company_id: str) -> Dict[str, Any]:
        """Download reports for a specific company"""
        company_config = self.companies[company_id]
        company_dir = self.raw_dir / company_id
        company_dir.mkdir(exist_ok=True)
        
        downloads = []
        
        for base_url in company_config['base_urls']:
            try:
                # Get the investor relations page
                async with session.get(base_url) as response:
                    if response.status != 200:
                        continue
                    
                    html = await response.text()
                    soup = BeautifulSoup(html, 'html.parser')
                    
                    # Find PDF links
                    pdf_links = await self._find_pdf_links(soup, base_url, company_config)
                    
                    # Download the most recent PDFs
                    for pdf_info in pdf_links[:3]:  # Limit to 3 most recent
                        try:
                            download_result = await self._download_pdf(session, pdf_info, company_dir)
                            if download_result:
                                downloads.append(download_result)
                        except Exception as e:
                            logger.error(f"Error downloading PDF {pdf_info['url']}: {e}")
                            continue
                
                if downloads:
                    break  # If we found downloads from first URL, don't try others
                    
            except Exception as e:
                logger.error(f"Error processing {base_url}: {e}")
                continue
        
        return {
            'company': company_config['name'],
            'downloads': downloads,
            'timestamp': datetime.now().isoformat()
        }

    async def _find_pdf_links(self, soup: BeautifulSoup, base_url: str, company_config: Dict) -> List[Dict[str, Any]]:
        """Find PDF links on the page"""
        pdf_links = []
        
        # Find all links
        links = soup.find_all('a', href=True)
        
        for link in links:
            href = link['href']
            text = link.get_text(strip=True).lower()
            
            # Make URL absolute
            if href.startswith('/'):
                from urllib.parse import urljoin
                href = urljoin(base_url, href)
            elif not href.startswith('http'):
                continue
            
            # Check if it's a PDF or leads to a PDF
            is_pdf_link = (
                href.lower().endswith('.pdf') or
                'pdf' in href.lower() or
                any(indicator in text for indicator in company_config['pdf_indicators'])
            )
            
            if is_pdf_link:
                # Check if it matches our search patterns
                relevance_score = 0
                for pattern in company_config['search_patterns']:
                    if re.search(pattern, text, re.IGNORECASE):
                        relevance_score += 2
                    if re.search(pattern, href, re.IGNORECASE):
                        relevance_score += 1
                
                # Extract potential quarter/year info
                quarter_match = re.search(r'q([1-4])', text, re.IGNORECASE)
                year_match = re.search(r'202([4-5])', text)
                
                pdf_links.append({
                    'url': href,
                    'text': text,
                    'relevance_score': relevance_score,
                    'quarter': quarter_match.group(1) if quarter_match else None,
                    'year': f"202{year_match.group(1)}" if year_match else None
                })
        
        # Sort by relevance and recency
        pdf_links.sort(key=lambda x: (x['relevance_score'], x['year'] or '0', x['quarter'] or '0'), reverse=True)
        
        return pdf_links

    async def _download_pdf(self, session: aiohttp.ClientSession, pdf_info: Dict, company_dir: Path) -> Optional[Dict[str, Any]]:
        """Download a single PDF"""
        try:
            url = pdf_info['url']
            
            # If URL doesn't end with .pdf, it might be a page with PDF link
            if not url.lower().endswith('.pdf'):
                # Try to find the actual PDF URL
                async with session.get(url) as response:
                    if response.status != 200:
                        return None
                    
                    html = await response.text()
                    soup = BeautifulSoup(html, 'html.parser')
                    
                    # Look for direct PDF links
                    pdf_link = soup.find('a', href=lambda x: x and x.lower().endswith('.pdf'))
                    if pdf_link:
                        from urllib.parse import urljoin
                        url = urljoin(url, pdf_link['href'])
                    else:
                        return None
            
            # Download the PDF
            async with session.get(url) as response:
                if response.status != 200:
                    return None
                
                content = await response.read()
                
                # Generate filename
                filename = self._generate_filename(pdf_info, url)
                file_path = company_dir / filename
                
                # Save PDF
                with open(file_path, 'wb') as f:
                    f.write(content)
                
                logger.info(f"Downloaded: {file_path}")
                
                return {
                    'filename': filename,
                    'path': str(file_path),
                    'url': url,
                    'size': len(content),
                    'quarter': pdf_info.get('quarter'),
                    'year': pdf_info.get('year'),
                    'download_time': datetime.now().isoformat()
                }
                
        except Exception as e:
            logger.error(f"Error downloading PDF from {pdf_info['url']}: {e}")
            return None

    def _generate_filename(self, pdf_info: Dict, url: str) -> str:
        """Generate a descriptive filename for the PDF"""
        # Extract filename from URL
        url_filename = url.split('/')[-1]
        if url_filename.lower().endswith('.pdf'):
            base_name = url_filename[:-4]
        else:
            base_name = "quarterly_report"
        
        # Add quarter and year if available
        if pdf_info.get('quarter') and pdf_info.get('year'):
            base_name += f"_Q{pdf_info['quarter']}_{pdf_info['year']}"
        elif pdf_info.get('year'):
            base_name += f"_{pdf_info['year']}"
        
        # Add timestamp to avoid conflicts
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        return f"{base_name}_{timestamp}.pdf"

    def get_downloaded_reports(self, company_id: Optional[str] = None) -> Dict[str, List[Dict]]:
        """Get list of downloaded reports"""
        reports = {}
        
        if company_id:
            companies_to_check = [company_id]
        else:
            companies_to_check = self.companies.keys()
        
        for comp_id in companies_to_check:
            company_dir = self.raw_dir / comp_id
            if company_dir.exists():
                pdf_files = list(company_dir.glob("*.pdf"))
                reports[comp_id] = []
                
                for pdf_file in pdf_files:
                    stat = pdf_file.stat()
                    reports[comp_id].append({
                        'filename': pdf_file.name,
                        'path': str(pdf_file),
                        'size': stat.st_size,
                        'modified': datetime.fromtimestamp(stat.st_mtime).isoformat()
                    })
                
                # Sort by modification time (newest first)
                reports[comp_id].sort(key=lambda x: x['modified'], reverse=True)
        
        return reports