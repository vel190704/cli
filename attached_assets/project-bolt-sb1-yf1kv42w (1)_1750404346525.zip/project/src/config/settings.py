import logging
import os
from pathlib import Path

def setup_logging(level: str = "INFO"):
    """Setup logging configuration"""
    log_level = getattr(logging, level.upper(), logging.INFO)
    
    # Create logs directory
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)
    
    # Configure logging
    logging.basicConfig(
        level=log_level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_dir / "chatbot.log"),
            logging.StreamHandler()
        ]
    )
    
    # Reduce noise from external libraries
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)
    logging.getLogger("aiohttp").setLevel(logging.WARNING)

# Application settings
DATA_DIR = "data"
OLLAMA_BASE_URL = "http://localhost:11434"
OLLAMA_MODEL = "llama3"

# Company configurations
COMPANIES = {
    'shell': {
        'name': 'Shell',
        'symbol': 'SHEL',
        'urls': [
            'https://www.shell.com/investors/financial-reporting/quarterly-results.html'
        ]
    },
    'bp': {
        'name': 'BP',
        'symbol': 'BP',
        'urls': [
            'https://www.bp.com/en/global/corporate/investors/results-and-reporting/quarterly-results.html'
        ]
    },
    'exxonmobil': {
        'name': 'ExxonMobil',
        'symbol': 'XOM',
        'urls': [
            'https://corporate.exxonmobil.com/investors/quarterly-earnings'
        ]
    },
    'chevron': {
        'name': 'Chevron',
        'symbol': 'CVX',
        'urls': [
            'https://www.chevron.com/investors/quarterly-earnings'
        ]
    }
}