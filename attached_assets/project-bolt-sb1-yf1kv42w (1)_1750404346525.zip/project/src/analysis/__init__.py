"""
Financial Analysis Package
"""