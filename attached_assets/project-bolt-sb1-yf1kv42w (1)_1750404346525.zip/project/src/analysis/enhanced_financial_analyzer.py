import logging
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
import json
from pathlib import Path
from ..database.models import Company, Report, FinancialData

logger = logging.getLogger(__name__)

class EnhancedFinancialAnalyzer:
    def __init__(self, db_session):
        self.db_session = db_session
        self.data_dir = Path("data")
        
    def get_latest_reports_summary(self) -> Dict[str, Any]:
        """Get summary of latest reports for welcome message"""
        try:
            # Try to get from database first
            companies = self.db_session.query(Company).all()
            summary = {}
            
            for company in companies:
                latest_report = (
                    self.db_session.query(Report)
                    .filter(Report.company_id == company.id)
                    .order_by(Report.quarter_year.desc())
                    .first()
                )
                
                if latest_report:
                    # Get key financial data
                    financial_data = (
                        self.db_session.query(FinancialData)
                        .filter(FinancialData.report_id == latest_report.id)
                        .all()
                    )
                    
                    metrics = {fd.metric_name: fd.value for fd in financial_data}
                    
                    # Generate key highlight
                    highlight = self._generate_key_highlight(company.name, metrics)
                    
                    summary[company.name] = {
                        'latest_quarter': f"{latest_report.quarter} {latest_report.year}",
                        'metrics': metrics,
                        'key_highlight': highlight
                    }
            
            # If no database data, try to get from parsed files
            if not summary:
                summary = self._get_summary_from_files()
            
            return summary
            
        except Exception as e:
            logger.error(f"Error getting latest reports summary: {e}")
            return {}

    def _get_summary_from_files(self) -> Dict[str, Any]:
        """Get summary from parsed JSON files"""
        summary = {}
        processed_dir = self.data_dir / "processed" / "json"
        
        if not processed_dir.exists():
            return summary
        
        for json_file in processed_dir.glob("*_parsed.json"):
            try:
                with open(json_file, 'r') as f:
                    data = json.load(f)
                
                company_name = data.get('company', json_file.stem.replace('_parsed', ''))
                
                if data.get('reports'):
                    latest_report = data['reports'][0]  # Assuming sorted by recency
                    metrics = latest_report.get('financial_metrics', {})
                    quarter_info = latest_report.get('quarter_info', {})
                    
                    highlight = self._generate_key_highlight(company_name, metrics)
                    
                    summary[company_name] = {
                        'latest_quarter': f"{quarter_info.get('quarter', 'Q1')} {quarter_info.get('year', '2025')}",
                        'metrics': metrics,
                        'key_highlight': highlight
                    }
                    
            except Exception as e:
                logger.error(f"Error reading {json_file}: {e}")
                continue
        
        return summary

    def _generate_key_highlight(self, company: str, metrics: Dict[str, Any]) -> str:
        """Generate a key highlight for the company"""
        try:
            revenue = metrics.get('revenue', 0)
            earnings = metrics.get('earnings', 0)
            cash_flow = metrics.get('free_cash_flow', metrics.get('cash_flow', 0))
            
            if revenue > 0:
                if earnings > 0:
                    return f"Generated ${revenue:.1f}B in revenue with ${earnings:.1f}B in earnings"
                else:
                    return f"Reported ${revenue:.1f}B in quarterly revenue"
            elif cash_flow > 0:
                return f"Strong cash flow generation of ${cash_flow:.1f}B"
            else:
                return "Latest quarterly results available for analysis"
                
        except Exception:
            return "Latest quarterly results available for analysis"

    def get_company_performance(self, company_name: str, quarters: Optional[List[str]] = None) -> Optional[Dict[str, Any]]:
        """Get detailed performance data for a company"""
        try:
            # Normalize company name
            company_name = self._normalize_company_name(company_name)
            
            # Try database first
            company = self.db_session.query(Company).filter(
                Company.name.ilike(f"%{company_name}%")
            ).first()
            
            if company:
                return self._get_company_data_from_db(company, quarters)
            else:
                return self._get_company_data_from_files(company_name, quarters)
                
        except Exception as e:
            logger.error(f"Error getting company performance for {company_name}: {e}")
            return None

    def _normalize_company_name(self, name: str) -> str:
        """Normalize company name for consistent lookup"""
        name_lower = name.lower()
        
        if 'shell' in name_lower:
            return 'Shell'
        elif 'bp' in name_lower:
            return 'BP'
        elif 'exxon' in name_lower:
            return 'ExxonMobil'
        elif 'chevron' in name_lower:
            return 'Chevron'
        else:
            return name.title()

    def _get_company_data_from_files(self, company_name: str, quarters: Optional[List[str]] = None) -> Optional[Dict[str, Any]]:
        """Get company data from parsed JSON files"""
        processed_dir = self.data_dir / "processed" / "json"
        
        # Try to find the company's parsed file
        possible_files = [
            f"{company_name.lower()}_parsed.json",
            f"{company_name.lower().replace(' ', '')}_parsed.json"
        ]
        
        for filename in possible_files:
            file_path = processed_dir / filename
            if file_path.exists():
                try:
                    with open(file_path, 'r') as f:
                        data = json.load(f)
                    
                    return self._process_company_file_data(data, quarters)
                    
                except Exception as e:
                    logger.error(f"Error reading {file_path}: {e}")
                    continue
        
        return None

    def _process_company_file_data(self, data: Dict[str, Any], quarters: Optional[List[str]] = None) -> Dict[str, Any]:
        """Process company data from file"""
        reports = data.get('reports', [])
        if not reports:
            return {}
        
        # Sort reports by recency (assuming newest first)
        latest_report = reports[0]
        previous_report = reports[1] if len(reports) > 1 else None
        
        result = {
            'company': data.get('company', 'Unknown'),
            'latest_quarter': latest_report.get('quarter_info', {}),
            'latest_metrics': latest_report.get('financial_metrics', {}),
            'highlights': latest_report.get('key_highlights', [])[:5]
        }
        
        if previous_report:
            result['previous_quarter'] = previous_report.get('quarter_info', {})
            result['previous_metrics'] = previous_report.get('financial_metrics', {})
            result['changes'] = self._calculate_changes(
                latest_report.get('financial_metrics', {}),
                previous_report.get('financial_metrics', {})
            )
        
        return result

    def _calculate_changes(self, current: Dict[str, Any], previous: Dict[str, Any]) -> Dict[str, float]:
        """Calculate percentage changes between quarters"""
        changes = {}
        
        for metric, current_value in current.items():
            if metric in previous and isinstance(current_value, (int, float)) and isinstance(previous[metric], (int, float)):
                if previous[metric] != 0:
                    change = ((current_value - previous[metric]) / previous[metric]) * 100
                    changes[metric] = round(change, 1)
        
        return changes

    def compare_companies(self, companies: List[str], quarters: Optional[List[str]] = None) -> Dict[str, Any]:
        """Compare multiple companies"""
        comparison_data = {}
        
        for company in companies:
            company_data = self.get_company_performance(company, quarters)
            if company_data:
                metrics = company_data.get('latest_metrics', {})
                comparison_data[company] = metrics
        
        # Create comparison summary
        if len(comparison_data) > 1:
            return self._create_comparison_summary(comparison_data)
        
        return comparison_data

    def _create_comparison_summary(self, company_data: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """Create a structured comparison summary"""
        summary = {
            'companies': list(company_data.keys()),
            'metrics_comparison': {},
            'rankings': {}
        }
        
        # Get all available metrics
        all_metrics = set()
        for metrics in company_data.values():
            all_metrics.update(metrics.keys())
        
        # Compare each metric
        for metric in all_metrics:
            metric_values = {}
            for company, metrics in company_data.items():
                if metric in metrics and isinstance(metrics[metric], (int, float)):
                    metric_values[company] = metrics[metric]
            
            if metric_values:
                summary['metrics_comparison'][metric] = metric_values
                
                # Create ranking
                sorted_companies = sorted(metric_values.items(), key=lambda x: x[1], reverse=True)
                summary['rankings'][metric] = [company for company, _ in sorted_companies]
        
        return summary

    def analyze_trends(self, company: str, metrics: List[str]) -> Dict[str, Any]:
        """Analyze trends for specific metrics"""
        company_data = self.get_company_performance(company)
        
        if not company_data:
            return {}
        
        trends = {}
        
        if 'changes' in company_data:
            for metric in metrics:
                if metric in company_data['changes']:
                    change = company_data['changes'][metric]
                    
                    if change > 5:
                        trend = 'Strong Growth'
                    elif change > 0:
                        trend = 'Growth'
                    elif change > -5:
                        trend = 'Slight Decline'
                    else:
                        trend = 'Significant Decline'
                    
                    trends[metric] = {
                        'change_percent': change,
                        'trend': trend,
                        'current_value': company_data.get('latest_metrics', {}).get(metric),
                        'previous_value': company_data.get('previous_metrics', {}).get(metric)
                    }
        
        return {
            'company': company,
            'trends': trends,
            'analysis_date': datetime.now().isoformat()
        }

    def get_market_context(self) -> str:
        """Get general market context"""
        context_snippets = [
            "Oil prices have shown volatility amid global economic uncertainties",
            "Energy companies continue to focus on capital discipline and shareholder returns",
            "The transition to renewable energy is influencing long-term strategic planning",
            "Geopolitical tensions continue to impact global energy markets",
            "Companies are balancing growth investments with cash flow generation"
        ]
        
        # In a real implementation, this would pull from market data APIs
        return ". ".join(context_snippets[:2]) + "."

    def get_recent_performance_summary(self) -> Dict[str, Any]:
        """Get a summary of recent performance across all companies"""
        try:
            all_companies = ['Shell', 'BP', 'ExxonMobil', 'Chevron']
            summary = {
                'sector_overview': {},
                'top_performers': {},
                'key_trends': []
            }
            
            company_metrics = {}
            for company in all_companies:
                data = self.get_company_performance(company)
                if data and data.get('latest_metrics'):
                    company_metrics[company] = data['latest_metrics']
            
            if company_metrics:
                # Calculate sector averages
                metrics_to_average = ['revenue', 'earnings', 'cash_flow', 'free_cash_flow']
                
                for metric in metrics_to_average:
                    values = [metrics.get(metric, 0) for metrics in company_metrics.values() 
                             if isinstance(metrics.get(metric), (int, float))]
                    if values:
                        summary['sector_overview'][f'avg_{metric}'] = sum(values) / len(values)
                
                # Identify top performers
                for metric in metrics_to_average:
                    metric_rankings = [(company, metrics.get(metric, 0)) 
                                     for company, metrics in company_metrics.items() 
                                     if isinstance(metrics.get(metric), (int, float))]
                    
                    if metric_rankings:
                        top_performer = max(metric_rankings, key=lambda x: x[1])
                        summary['top_performers'][metric] = {
                            'company': top_performer[0],
                            'value': top_performer[1]
                        }
            
            return summary
            
        except Exception as e:
            logger.error(f"Error getting recent performance summary: {e}")
            return {}