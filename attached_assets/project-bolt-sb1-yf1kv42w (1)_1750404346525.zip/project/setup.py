from setuptools import setup, find_packages

setup(
    name="oil-gas-financial-chatbot",
    version="1.0.0",
    description="Conversational AI chatbot for oil & gas financial analysis",
    packages=find_packages(),
    install_requires=[
        "aiohttp>=3.9.1",
        "beautifulsoup4>=4.12.2",
        "pdfplumber>=0.10.3",
        "requests>=2.31.0",
        "sqlalchemy>=2.0.23",
        "lxml>=4.9.3",
        "python-dateutil>=2.8.2",
    ],
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "oil-gas-chatbot=main:main",
        ],
    },
)